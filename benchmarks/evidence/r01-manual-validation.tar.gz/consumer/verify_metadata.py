from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import sys
from pathlib import Path
from zipfile import ZipFile

expected = {
    'h2hdb': ('h2hdb', '0.45.7', Path('/private/tmp/h2hdb-r01-skill/wheels/h2hdb-0.45.7-py3-none-any.whl')),
    'h2hdb-ingest': ('h2hdb_ingest', '0.30.3', Path('/private/tmp/h2hdb-cleanup-role-wheels/h2hdb_ingest-0.30.3-py3-none-any.whl')),
}
report: dict[str, object] = {
    'python': sys.version,
    'executable': sys.executable,
    'prefix': sys.prefix,
    'isolated': bool(sys.flags.isolated),
    'candidate_wheels': {},
    'installed_distributions': [],
}
wheel_records: dict[str, object] = {}
for name, (module_name, expected_version, wheel) in expected.items():
    package = importlib.metadata.distribution(name)
    assert package.version == expected_version, (name, package.version)
    direct = json.loads(package.read_text('direct_url.json') or '{}')
    wheel_hash = hashlib.sha256(wheel.read_bytes()).hexdigest()
    assert direct.get('url') == wheel.as_uri(), direct
    archive_info = direct.get('archive_info', {})
    recorded_hash = archive_info.get('hashes', {}).get('sha256')
    assert recorded_hash is None or recorded_hash == wheel_hash, direct
    assert not direct.get('dir_info', {}).get('editable', False), direct
    module = importlib.import_module(module_name)
    imported = Path(module.__file__).resolve()
    assert imported.is_relative_to(Path(sys.prefix).resolve()), imported
    assert imported == Path(package.locate_file(module_name + '/__init__.py')).resolve()
    with ZipFile(wheel) as archive:
        metadata_name = next(item for item in archive.namelist() if item.endswith('.dist-info/METADATA'))
        wheel_metadata = archive.read(metadata_name).decode()
        package_files = [item for item in archive.namelist() if item.startswith(module_name + '/') and not item.endswith('/')]
        for item in package_files:
            assert Path(package.locate_file(item)).read_bytes() == archive.read(item), item
    assert package.read_text('METADATA') == wheel_metadata
    wheel_records[name] = {
        'path': str(wheel),
        'sha256': wheel_hash,
        'version': package.version,
        'direct_url': direct,
        'module_file': str(imported),
        'metadata_exactly_matches_wheel': True,
        'installed_package_files_exactly_match_wheel': len(package_files),
        'direct_url_records_sha256': recorded_hash is not None,
        'requires_dist': package.requires or [],
    }
report['candidate_wheels'] = wheel_records
assert importlib.metadata.version('pydantic') == '2.14.0'
for name in ('pydantic', 'h2h_galleryinfo_parser'):
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()), module.__file__
installed = []
for package in sorted(importlib.metadata.distributions(), key=lambda item: item.metadata['Name'].lower()):
    installed.append({
        'name': package.metadata['Name'],
        'version': package.version,
        'location': str(package.locate_file('')),
        'direct_url': json.loads(package.read_text('direct_url.json') or '{}'),
        'requires_python': package.metadata.get('Requires-Python'),
        'requires_dist': package.requires or [],
    })
report['installed_distributions'] = installed
print(json.dumps(report, indent=2, sort_keys=True))
