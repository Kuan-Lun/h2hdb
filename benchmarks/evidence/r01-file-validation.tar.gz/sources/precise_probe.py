"""R01 disposable local family-read comparison; no existing database is opened."""
import argparse
import ast
from collections import Counter
from contextlib import contextmanager
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import subprocess
import sys
import time
import tracemalloc
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--backend', choices=('sqlite', 'mariadb'), required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--suite', choices=('sanity', 'main'), default='sanity')
parser.add_argument('--baseline-ref', default='041f707')
args = parser.parse_args()
root = args.root.resolve()
sys.path[:0] = [str(root / p) for p in ('src', 'scripts', 'tests')]
import h2hdb.vnext_analysis_repository as analysis
from h2hdb.vnext_transaction import VNextUnitOfWork
from ingest_growth_hash_probe import databases, profile_mariadb, require_point_work_bound, record
from vnext_test_database import set_foreign_key_checks

baseline_source = subprocess.check_output(['git', '-C', str(root), 'show',
                                           args.baseline_ref + ':src/h2hdb/vnext_analysis_repository.py'])
baseline_node = next(node for node in ast.parse(baseline_source).body
                     if isinstance(node, ast.FunctionDef) and node.name == '_load_file_decision_evidence')
baseline_namespace = dict(vars(analysis))
exec(compile(ast.Module(body=[baseline_node], type_ignores=[]),
             '<historical-file-decision-evidence>', 'exec'), baseline_namespace)
historical_helper = baseline_namespace['_load_file_decision_evidence']

CONTRACT = {
    'version': 1,
    'sql': 'fresh layout 2 per non-null root; family 2*ceil(U/17)',
    'returned_family_grid_rows': '2*K*U',
    'max_family_primary_key_probes': '6*K*U',
    'cpu_seconds_per_key': 0.001,
    'wall_seconds_per_key': 0.005,
    'python_peak_bytes_per_call': 8 * 1024 * 1024,
    'main_acceptance': 'overlapping main cases candidate median wall < baseline median wall',
    'repetitions': 3,
    'page_keys': 128,
}
SHADOWS = (
    ('catalog_a_file_decision_shadow_anchors', None),
    ('catalog_a_file_decision_shadow_occurrences', 'occurrence_count'),
    ('catalog_a_file_decision_shadow_artists', 'artist_count'),
    ('catalog_a_file_decision_shadow_gallery_artist_max', 'maximum_gallery_artist_count'),
    ('catalog_a_file_decision_shadow_seals', None),
)


def persist(report):
    args.output.write_text(json.dumps(report, indent=2) + '\n')


def hash_source():
    return {
        str(path.relative_to(root)) if path.is_relative_to(root) else path.name:
        sha256(path.read_bytes()).hexdigest()
        for path in (root / 'src/h2hdb/vnext_analysis_repository.py',
                     root / 'src/h2hdb/vnext_analysis_decision_batch.py',
                     root / 'scripts/ingest_growth_hash_probe.py', Path(__file__))
    }


def scalar(index, changed=False):
    # Already-aggregated decision values: 80% singleton, 10% moderately shared,
    # 10% high multiplicity; this does not reconstruct source gallery artists.
    occurrence, artists, maximum = ((1, 1, 1) if index % 10 < 8 else
                                    (4, 3, 2) if index % 10 == 8 else (32, 17, 8))
    return occurrence + int(changed), artists, maximum


def batches(rows, limit=256):
    for offset in range(0, len(rows), limit):
        yield rows[offset:offset + limit]


def seed(connector, *, retained, baseline_layers, mode, reuse_percent):
    current = (100).to_bytes(16, 'big')
    ancestors = tuple(index.to_bytes(16, 'big') for index in range(1, baseline_layers + 1))
    baseline = ancestors[0] if ancestors else None
    current_ancestry = (current, *ancestors) if mode == 'overlay' else (current,)
    keys = tuple(index.to_bytes(32, 'big') for index in range(retained))
    set_foreign_key_checks(connector, enabled=False)
    facts = []
    current_own = set()
    with connector.transaction():
        for index, owner in enumerate(ancestors):
            connector.execute_many(
                'INSERT INTO catalog_analysis_state_ancestry '
                '(analysis_id, ancestor_depth, ancestor_analysis_id) VALUES (%s,%s,%s)',
                [(owner, depth, ancestor) for depth, ancestor in enumerate(ancestors[index:])])
            if index + 1 < len(ancestors):
                connector.execute('INSERT INTO catalog_analysis_baselines '
                                  '(analysis_id, base_analysis_id) VALUES (%s,%s)',
                                  (owner, ancestors[index + 1]))
        connector.execute_many('INSERT INTO catalog_analysis_state_ancestry '
                               '(analysis_id, ancestor_depth, ancestor_analysis_id) VALUES (%s,%s,%s)',
                               [(current, depth, owner) for depth, owner in enumerate(current_ancestry)])
        if baseline:
            connector.execute('INSERT INTO catalog_analysis_baselines '
                              '(analysis_id, base_analysis_id) VALUES (%s,%s)', (current, baseline))
        for index, key in enumerate(keys):
            if baseline:
                facts.append((ancestors[index % len(ancestors)], key, scalar(index)))
            changed = mode == 'overlay' and index % 100 >= reuse_percent
            if mode != 'overlay' or changed:
                facts.append((current, key, scalar(index, changed)))
                current_own.add(key)
        for table, column in SHADOWS:
            rows = [(owner, key) if column is None else
                    (owner, key, values[('occurrence_count', 'artist_count',
                                         'maximum_gallery_artist_count').index(column)])
                    for owner, key, values in facts]
            columns = 'analysis_id,file_sha256' + ('' if column is None else ',' + column)
            placeholders = '%s,%s' + ('' if column is None else ',%s')
            for chunk in batches(rows):
                connector.execute_many(f'INSERT INTO {table} ({columns}) VALUES ({placeholders})', chunk)
    return (baseline, current), keys, ancestors, current_ancestry, current_own, len(facts)


def invoke(work, roots, keys, variant):
    if variant == 'candidate':
        return analysis._load_file_decision_evidence(work, roots, keys)
    return tuple(historical_helper(work, owner, keys) for owner in roots)


def oracle(pair, keys, roots, mode, reuse_percent, current_own):
    parents, current = pair
    expected_parent = {} if roots[0] is None else {key: scalar(int.from_bytes(key, 'big')) for key in keys}
    expected_current = {
        key: scalar(int.from_bytes(key, 'big'), mode == 'overlay' and
                    int.from_bytes(key, 'big') % 100 >= reuse_percent) for key in keys}
    def values(result):
        return {key: (value.occurrence_count, value.artist_count, value.maximum_gallery_artist_count)
                for key, value in result.items()}
    assert values(parents.resolved) == expected_parent
    assert values(current.resolved) == expected_current
    assert values(current.own_shadows) == {key: value for key, value in expected_current.items() if key in current_own}
    assert not current.own_tombstones and not parents.own_tombstones


@contextmanager
def observe(connector):
    observations = []
    original = connector.fetch_all
    def fetch(sql, parameters=()):
        rows = original(sql, parameters)
        if sql.startswith('WITH requested_analyses(analysis_id) AS ('):
            kind = 'tombstone' if 'LEFT JOIN catalog_analysis_file_hash_decision_tombstone ' in sql else 'shadow'
            layers = tuple(value for value in parameters[:-1] if isinstance(value, bytes) and len(value) == 16)
            keys = tuple(value for value in parameters[:-1] if isinstance(value, bytes) and len(value) == 32)
            assert len(layers) <= 17 and len(keys) <= 128
            assert len(rows) == len(layers) * len(keys)
            observations.append((kind, layers, len(rows)))
        return rows
    with patch.object(connector, 'fetch_all', fetch):
        yield observations


def check_unique_reads(observed, *, unique_layers, key_count):
    assert len(observed) == 2 * ((unique_layers + 16) // 17), 'family query budget exceeded'
    assert sum(rows for _, _, rows in observed) == 2 * unique_layers * key_count, 'family row budget exceeded'
    for kind in ('shadow', 'tombstone'):
        counted = Counter(owner for found, layers, _ in observed if found == kind for owner in layers)
        assert len(counted) == unique_layers and set(counted.values()) == {1}, 'repeated family layer read'


def measure_case(connector, shape):
    roots, all_keys, baseline_ancestry, current_ancestry, own, family_count = seed(connector, **{k: v for k, v in shape.items() if k != 'requested'})
    keys = all_keys[:shape['requested']]
    work = VNextUnitOfWork(connector, backend=args.backend)
    unique_layers = len(set(baseline_ancestry + current_ancestry))
    samples = []
    plans = []
    negative_rejected = False
    # Per-call ownership/work is checked outside timing; neither candidate nor
    # baseline gains a result/layout cache between calls or cycles.
    structural = {'candidate_queries': 0, 'candidate_grid_rows': 0,
                  'baseline_queries': 0, 'baseline_grid_rows': 0}
    for page in batches(keys, 128):
        for variant in ('candidate', 'baseline'):
            with connector.read_transaction(), observe(connector) as observed:
                pair = invoke(work, roots, page, variant)
            oracle(pair, page, roots, shape['mode'], shape['reuse_percent'], own)
            structural[variant + '_queries'] += len(observed)
            structural[variant + '_grid_rows'] += sum(value[2] for value in observed)
            if variant == 'candidate':
                check_unique_reads(observed, unique_layers=unique_layers, key_count=len(page))
            elif set(baseline_ancestry) & set(current_ancestry):
                try:
                    check_unique_reads(observed, unique_layers=unique_layers, key_count=len(page))
                except AssertionError:
                    negative_rejected = True
                else:
                    raise AssertionError('original double reads were not rejected')
    if set(baseline_ancestry) & set(current_ancestry):
        assert negative_rejected
    # Native MariaDB work is profiled on the real first-page queries after the
    # structural pass, with EXPLAIN/ANALYZE outside timed measurements.
    for variant in ('candidate', 'baseline'):
        with connector.read_transaction(), record(connector) as recorder:
            pair = invoke(work, roots, keys[:128], variant)
        oracle(pair, keys[:128], roots, shape['mode'], shape['reuse_percent'], own)
        queries = []
        for query in recorder.queries:
            if query.kind not in ('shadow_family_points', 'tombstone_points'):
                continue
            if args.backend == 'mariadb':
                with connector.read_transaction():
                    query.plan = profile_mariadb(connector, query)
                require_point_work_bound(query)
            else:
                with connector.read_transaction():
                    query.plan = connector.fetch_all('EXPLAIN QUERY PLAN ' + query.sql, query.parameters)
            row = asdict(query)
            row['parameters'] = [item.hex() if isinstance(item, bytes) else item for item in query.parameters]
            queries.append(row)
        plans.append({'variant': variant, 'queries': queries})
    # Fixed per-call peaks, reported separately so tracemalloc does not distort
    # the three paired elapsed/CPU sample cycles.
    peaks = {}
    for variant in ('candidate', 'baseline'):
        peaks[variant] = 0
        for page in (keys[:128], keys[-128:]):
            with connector.read_transaction():
                tracemalloc.start()
                try:
                    pair = invoke(work, roots, page, variant)
                    _, peak = tracemalloc.get_traced_memory()
                finally:
                    tracemalloc.stop()
            oracle(pair, page, roots, shape['mode'], shape['reuse_percent'], own)
            peaks[variant] = max(peaks[variant], peak)
        assert peaks[variant] <= CONTRACT['python_peak_bytes_per_call']
    for repetition in range(CONTRACT['repetitions']):
        order = ('baseline', 'candidate') if repetition % 2 == 0 else ('candidate', 'baseline')
        for variant in order:
            elapsed = cpu = 0.0
            for page in batches(keys, 128):
                with connector.read_transaction():
                    wall_start, cpu_start = time.perf_counter(), time.process_time()
                    pair = invoke(work, roots, page, variant)
                    cpu += time.process_time() - cpu_start
                    elapsed += time.perf_counter() - wall_start
                oracle(pair, page, roots, shape['mode'], shape['reuse_percent'], own)
            samples.append({'variant': variant, 'cycle': repetition, 'seconds': elapsed,
                            'cpu_seconds': cpu, 'keys': len(keys), 'pages': (len(keys) + 127) // 128})
    medians = {variant: {field: median(sample[field] for sample in samples if sample['variant'] == variant)
                        for field in ('seconds', 'cpu_seconds')} for variant in ('baseline', 'candidate')}
    for field, budget in (('seconds', CONTRACT['wall_seconds_per_key']),
                          ('cpu_seconds', CONTRACT['cpu_seconds_per_key'])):
        assert medians['candidate'][field] <= budget * len(keys), f'fixed {field} budget exceeded'
    verdict = None
    if shape['retained'] >= 4096 and shape['requested'] == shape['retained'] and shape['mode'] == 'overlay':
        verdict = medians['candidate']['seconds'] < medians['baseline']['seconds']
        assert verdict, 'main overlap workload did not produce net local wall benefit'
    return {'shape': shape, 'baseline_layers': len(baseline_ancestry),
            'current_layers': len(current_ancestry), 'unique_layers': unique_layers,
            'stored_shadow_families': family_count, 'physical_shadow_rows': 5 * family_count,
            'scalar_distribution': {'singleton': '80%', '4_occurrences_3_artists_max2': '10%',
                                    '32_occurrences_17_artists_max8': '10%'},
            'oracle_matches': True, 'negative_control_rejected': negative_rejected,
            'structural': structural, 'samples': samples, 'medians': medians,
            'python_peak_bytes_per_call': peaks, 'main_net_wall_benefit': verdict,
            'representative_native_queries': plans}


cases = ([
    {'retained': k, 'requested': k, 'baseline_layers': 1, 'mode': 'overlay', 'reuse_percent': 95}
    for k in (1, 127, 128, 129, 257)
] + [
    {'retained': 129, 'requested': 129, 'baseline_layers': b, 'mode': mode, 'reuse_percent': 95}
    for b, mode in ((0, 'genesis'), (8, 'policy_change'), (17, 'compaction'))
]) if args.suite == 'sanity' else [
    {'retained': retained, 'requested': requested, 'baseline_layers': depth,
     'mode': 'overlay', 'reuse_percent': reuse}
    for retained, requested, depth, reuse in (
        (4096, 4096, 8, 95), (32768, 32768, 16, 95),
        (4096, 4096, 8, 0), (32768, 32768, 16, 0),
        (4096, 128, 8, 95), (32768, 128, 8, 95),
    )
]
report = {'status': 'incomplete', 'backend': args.backend, 'contract': CONTRACT,
          'invocation': [sys.executable, *sys.argv],
          'git_head': subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
          'source_sha256': hash_source(), 'baseline_ref': args.baseline_ref,
          'baseline_source_sha256': sha256(baseline_source).hexdigest(),
          'baseline_function_sha256': sha256(ast.get_source_segment(baseline_source.decode(), baseline_node).encode()).hexdigest(), 'cases': [],
          'limits': ['Synthetic scalar family/layout fixture, foreign keys disabled; no complete source or run authority.',
                     'Artist and occurrence values are aggregate scalars, not an inferred source artist/gallery distribution.',
                     'Baseline executes the exact historical private helper AST with unchanged layout/family dependencies; it is not an end-to-end historical deployment.',
                     'Only pair-loader local work; issue/prepare/commit checkpoints, full source aggregation, publication, cleanup and READY are outside scope.',
                     'Physical PK probe budget uses accepted native MariaDB query plans; handler operations are not exact rows examined.',
                     'SQLite VM values are 100-opcode samples; no universal wall or NAS/pipeline SLO.',
                     '8 MiB peak applies to per-call traced Python allocations, not database server or process RSS.']}
persist(report)
try:
    with databases(args.backend, len(cases)) as connections:
        for connector, shape in zip(connections, cases, strict=True):
            result = measure_case(connector, shape)
            report['cases'].append(result)
            persist(report)
            print(json.dumps({'shape': shape, 'structural': result['structural'], 'medians': result['medians'],
                              'peak': result['python_peak_bytes_per_call']}), flush=True)
    assert report['source_sha256'] == hash_source(), 'sources changed during measurement'
    report['status'] = 'completed'
except BaseException as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    persist(report)
    raise
persist(report)
